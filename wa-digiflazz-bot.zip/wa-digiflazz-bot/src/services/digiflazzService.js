const axios = require('axios');
const crypto = require('crypto');

module.exports = {
    async createOrder(productCode, customerNumber, refId) {
        const url = process.env.DIGIFLAZZ_URL;
        const username = process.env.DIGIFLAZZ_USERNAME;
        const apiKey = process.env.DIGIFLAZZ_API_KEY;

        const signature = crypto
            .createHash('md5')
            .update(`${username}${apiKey}${refId}`)
            .digest('hex');

        const payload = {
            username,
            buyer_sku_code: productCode,
            customer_no: customerNumber,
            ref_id: refId,
            sign: signature
        };

        try {
            const response = await axios.post(url, payload);
            return response.data;
        } catch (error) {
            console.error('Error in Digiflazz API request:', error.response?.data || error.message);
            throw error;
        }
    }
};