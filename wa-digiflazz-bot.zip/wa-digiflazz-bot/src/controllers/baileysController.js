// File di folder controllers: baileysController.js
const { default: makeWASocket, DisconnectReason, useSingleFileAuthState } = require('@adiwajshing/baileys');
const { Boom } = require('@hapi/boom');
const { writeFileSync } = require('fs');

const { state, saveState } = useSingleFileAuthState('./auth_info.json');

module.exports = {
    startWhatsAppBot() {
        const sock = makeWASocket({
            auth: state,
            printQRInTerminal: true, // QR code akan ditampilkan di terminal
        });

        sock.ev.on('connection.update', (update) => {
            const { connection, lastDisconnect } = update;
            if (connection === 'close') {
                const shouldReconnect = (lastDisconnect.error?.output?.statusCode !== DisconnectReason.loggedOut);
                console.log('Connection closed. Reconnecting:', shouldReconnect);
                if (shouldReconnect) {
                    this.startWhatsAppBot();
                }
            } else if (connection === 'open') {
                console.log('Connected to WhatsApp');
            }
        });

        sock.ev.on('creds.update', saveState);

        sock.ev.on('messages.upsert', async (msg) => {
            const message = msg.messages[0];
            if (!message.message || message.key.fromMe) return;

            const sender = message.key.remoteJid;
            const text = message.message.conversation || message.message.extendedTextMessage?.text;

            console.log(`Message from ${sender}: ${text}`);

            // Balas pesan
            if (text === 'halo') {
                await sock.sendMessage(sender, { text: 'Halo! Ada yang bisa saya bantu?' });
            } else if (text === 'cek saldo') {
                await sock.sendMessage(sender, { text: 'Saldo Anda adalah 100.000' }); // Contoh pesan
            }
        });
    }
};