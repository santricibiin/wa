// File di folder controllers: digiflazzController.js
const digiflazzService = require('../services/digiflazzService');

module.exports = {
    async handleWebhook(req, res) {
        console.log('Webhook received:', req.body);
        res.status(200).send('Webhook received');
    },

    async createOrder(req, res) {
        try {
            const { productCode, customerNumber, refId } = req.body;
            const orderResponse = await digiflazzService.createOrder(productCode, customerNumber, refId);
            res.status(200).json(orderResponse);
        } catch (error) {
            console.error('Error creating order:', error);
            res.status(500).send('Failed to create order');
        }
    }
};
