// Struktur folder sudah ditentukan di komentar sebelumnya. Berikut adalah file utama `app.js`.

require('dotenv').config(); // Memuat variabel dari file .env
const express = require('express');
const bodyParser = require('body-parser');
const digiflazzController = require('./controllers/digiflazzController');
const baileysController = require('./controllers/baileysController');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.json());

// Routes
app.post('/webhook', digiflazzController.handleWebhook);
app.post('/order', digiflazzController.createOrder);

// Start server
app.listen(PORT, () => {
    console.log(`Bot running on http://localhost:${PORT}`);
    baileysController.startWhatsAppBot(); // Mulai koneksi WhatsApp
});

